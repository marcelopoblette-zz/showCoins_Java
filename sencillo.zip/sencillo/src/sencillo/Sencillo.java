/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sencillo;

import java.util.Scanner;

/**
 *
 * @author Marcelo
 */
public class Sencillo {

    private int cent;

    public int getCent() {
        return cent;
    }

    public void setCent(int cent) {
        this.cent = cent;
    }

    public Sencillo(int cent) {
        this.cent = cent;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        int unidades;
        unidades = Integer.parseInt(solicitaNumero());;
        Sencillo monedas = new Sencillo(unidades);
        giveCoins(monedas.getCent());

        printCoins(giveCoins(monedas.getCent()));
    }

    public static boolean validaInt(String num) {
        try {
            Integer.parseInt(num);
        } catch (Exception e) {
            return false;
        }
        return true;
    }

    public static String solicitaNumero() {

        String Numero;
        Scanner entrada = new Scanner(System.in);
        boolean boolIterador = false;
        do {
            do {
                System.out.println("Enter the number of cents; ");
                Numero = entrada.next();
                if (validaInt(Numero) == true) {
                    boolIterador = false;
                } else {
                    System.out.println("Please, enter a number.");
                    boolIterador = true;
                }
            } while (boolIterador);
        } while (boolIterador);
        return Numero;
    }

    public static int[] giveCoins(int cent) {
        int dollar = cent / 100;
        cent = cent % 100;

        int quarter = cent / 25;
        cent = cent % 25;

        int dime = cent / 10;
        cent = cent % 10;

        int nickel = cent / 5;
        cent = cent % 5;

        int[] result = {dollar, quarter, dime, nickel, cent};
        return result;
    }

    public static void printCoins(int[] coins) {
        System.out.print(" You have entered ");
        int dollar = coins[0];
        int quarter = coins[1];
        int dime = coins[2];
        int nickel = coins[3];
        int cent = coins[4];
        if (dollar > 0) {
            System.out.print((dollar) + " dollar, ");
        }
        if (quarter > 0) {
            System.out.print((quarter) + " quarter, ");
        }
        if (dime > 0) {
            System.out.print((dime) + " dime, ");
        }
        if (nickel > 0) {
            System.out.print((nickel) + " nickel, ");
        }
        if (cent > 0) {
            System.out.print(cent + " cent(s). ");
        }
    }
}
